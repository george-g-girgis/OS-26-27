/* See COPYRIGHT for copyright information. */

#include <inc/x86.h>
#include <inc/memlayout.h>
#include <inc/kbdreg.h>
#include <inc/string.h>
#include <inc/assert.h>
#include <kern/trap/trap.h>
#include <kern/proc/user_environment.h>
#include <kern/cpu/sched_helpers.h>
#include <kern/cpu/cpu.h>
#include <kern/cpu/kclock.h>
#include <kern/conc/channel.h>

#include "console.h"


void cons_intr(int (*proc)(void));
int text_length = 0;

/***** Serial I/O code *****/

#define COM1		0x3F8

#define COM_RX		0	// In:	Receive buffer (DLAB=0)
#define COM_DLL		0	// Out: Divisor Latch Low (DLAB=1)
#define COM_DLM		1	// Out: Divisor Latch High (DLAB=1)
#define COM_IER		1	// Out: Interrupt Enable Register
#define   COM_IER_RDI	0x01	//   Enable receiver data interrupt
#define COM_IIR		2	// In:	Interrupt ID Register
#define COM_FCR		2	// Out: FIFO Control Register
#define COM_LCR		3	// Out: Line Control Register
#define	  COM_LCR_DLAB	0x80	//   Divisor latch access bit
#define	  COM_LCR_WLEN8	0x03	//   Wordlength: 8 bits
#define COM_MCR		4	// Out: Modem Control Register
#define	  COM_MCR_RTS	0x02	// RTS complement
#define	  COM_MCR_DTR	0x01	// DTR complement
#define	  COM_MCR_OUT2	0x08	// Out2 complement
#define COM_LSR		5	// In:	Line Status Register
#define   COM_LSR_DATA	0x01	//   Data available

static bool serial_exists;

int
serial_proc_data(void)
{
	if (!(inb(COM1+COM_LSR) & COM_LSR_DATA))
		return -1;
	return inb(COM1+COM_RX);
}

void
serial_intr(void)
{
	if (serial_exists)
		cons_intr(serial_proc_data);
}

void serial_interrupt_handler(struct Trapframe* tf)
{
	cprintf("\nserial interrupt\n");
	serial_intr();
}

void
serial_init(void)
{
	// Turn off the FIFO
	outb(COM1+COM_FCR, 0);

	// Set speed; requires DLAB latch
	outb(COM1+COM_LCR, COM_LCR_DLAB);
	outb(COM1+COM_DLL, (uint8) (115200 / 9600));
	outb(COM1+COM_DLM, 0);

	// 8 data bits, 1 stop bit, parity off; turn off DLAB latch
	outb(COM1+COM_LCR, COM_LCR_WLEN8 & ~COM_LCR_DLAB);

	// No modem controls
	outb(COM1+COM_MCR, 0);
	// Enable rcv interrupts
	outb(COM1+COM_IER, COM_IER_RDI);

	// Clear any preexisting overrun indications and interrupts
	// Serial port doesn't exist if COM_LSR returns 0xFF
	serial_exists = (inb(COM1+COM_LSR) != 0xFF);
	(void) inb(COM1+COM_IIR);
	(void) inb(COM1+COM_RX);

	irq_install_handler(4, &serial_interrupt_handler);

}



/***** Parallel port output code *****/
// For information on PC parallel port programming, see the class References
// page.

// Stupid I/O delay routine necessitated by historical PC design flaws
static void
delay(void)
{
	inb(0x84);
	inb(0x84);
	inb(0x84);
	inb(0x84);
}

static void
lpt_putc(int c)
{
	int i;

	for (i = 0; !(inb(0x378+1) & 0x80) && i < 2800; i++) //12800
		delay();
	outb(0x378+0, c);
	outb(0x378+2, 0x08|0x04|0x01);
	outb(0x378+2, 0x08);
}




/***** Text-mode CGA/VGA display output *****/

static unsigned addr_6845;
static uint16 *crt_buf;
static uint16 crt_pos;

void
cga_init(void)
{
	volatile uint16 *cp;
	uint16 was;
	unsigned pos;

	cp = (uint16*) (KERNEL_BASE + CGA_BUF);
	was = *cp;
	*cp = (uint16) 0xA55A;
	if (*cp != 0xA55A) {
		cp = (uint16*) (KERNEL_BASE + MONO_BUF);
		addr_6845 = MONO_BASE;
	} else {
		*cp = was;
		addr_6845 = CGA_BASE;
	}

	/* Extract cursor location */
	outb(addr_6845, 14);
	pos = inb(addr_6845 + 1) << 8;
	outb(addr_6845, 15);
	pos |= inb(addr_6845 + 1);

	crt_buf = (uint16*) cp;
	crt_pos = pos;
}

//2016: Preliminary backward and forward cursor movement was added to FOS
// 		Thanks to student Abdullah Mohammad Ma3en, 3rd year, and TA Ghada Hamed.
void
cga_putc(int c)
{
	// if no attribute given, then use the text color
	if (!(c & ~0xFF))
	{
		c |= current_text_color == 0? 0x700 : current_text_color;
		//c |= 0x700; /*black and white*/
	}
	switch (c & 0xff) {
	case '\b':
		if (crt_pos > 0) {
			crt_pos--;
			crt_buf[crt_pos] = (c & ~0xff) | ' ';
		}
		break;
	case '\n':
		crt_pos += CRT_COLS;
		text_length = 0;
		/* fallthru */
	case '\r':
		crt_pos -= (crt_pos % CRT_COLS);
		break;
	case '\t':
		cons_putc(' ');
		cons_putc(' ');
		cons_putc(' ');
		cons_putc(' ');
		cons_putc(' ');
		break;
	case KEY_LF:
		if(crt_pos>0)
			crt_pos--;
		break;
	case KEY_RT:
		if (crt_pos < CRT_SIZE)
			crt_pos++;
		break;
	default: {
		if (c != KEY_LF && c != KEY_RT) {
			crt_buf[crt_pos++] = c;		/* write the character */
			if (crt_pos > 1920 + text_length)
				text_length++;
		}
		break;
	}
	}

	// What is the purpose of this?
	if (crt_pos >= CRT_SIZE) {
		int i;

		memcpy(crt_buf, crt_buf + CRT_COLS, (CRT_SIZE - CRT_COLS) * sizeof(uint16));
		for (i = CRT_SIZE - CRT_COLS; i < CRT_SIZE; i++)
			crt_buf[i] = 0x0700 | ' ';
		crt_pos -= CRT_COLS;
	}

	/* move that little blinky thing */
	outb(addr_6845, 14);
	outb(addr_6845 + 1, crt_pos >> 8);
	outb(addr_6845, 15);
	outb(addr_6845 + 1, crt_pos);
}


/***** Keyboard input code *****/

#define NO		0

#define SHIFT		(1<<0)
#define CTL		(1<<1)
#define ALT		(1<<2)

#define CAPSLOCK	(1<<3)
#define NUMLOCK		(1<<4)
#define SCROLLLOCK	(1<<5)

#define E0ESC		(1<<6)

static uint8 shiftcode[256] = { [0x1D] CTL, [0x2A] SHIFT, [0x36] SHIFT, [0x38
																		 ] ALT, [0x9D] CTL, [0xB8] ALT };

static uint8 togglecode[256] = { [0x3A] CAPSLOCK, [0x45] NUMLOCK, [0x46
																   ] SCROLLLOCK };

static uint8 normalmap[256] = {
		NO, 0x1B, '1', '2', '3', '4', '5',
		'6',	// 0x00
		'7', '8', '9', '0', '-', '=', '\b', '\t', 'q', 'w', 'e', 'r', 't', 'y',
		'u',
		'i',	// 0x10
		'o', 'p', '[', ']', '\n', NO, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k',
		'l',
		';',	// 0x20
		'\'', '`', NO, '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/',
		NO,
		'*',	// 0x30
		NO,   ' ',  NO,   NO,   NO,   NO,   NO,   NO,
		NO, NO, NO, NO, NO, NO, NO,
		'7',	// 0x40
		'8', '9', '-', '4', '5', '6', '+', '1', '2', '3', '0', '.', NO, NO, NO,
		NO,	// 0x50
		[0x97] KEY_HOME, [0x9C] '\n' /*KP_Enter*/, [0xB5] '/' /*KP_Div*/, [0xC8
																		   ] KEY_UP, [0xC9] KEY_PGUP, [0xCB] KEY_LF, [0xCD] KEY_RT, [0xCF
																																	 ] KEY_END, [0xD0] KEY_DN, [0xD1] KEY_PGDN, [0xD2] KEY_INS, [0xD3
																																																 ] KEY_DEL };

static uint8 shiftmap[256] = {
		NO, 033, '!', '@', '#', '$', '%',
		'^',	// 0x00
		'&', '*', '(', ')', '_', '+', '\b', '\t', 'Q', 'W', 'E', 'R', 'T', 'Y',
		'U',
		'I',	// 0x10
		'O', 'P', '{', '}', '\n', NO, 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K',
		'L',
		':',	// 0x20
		'"', '~', NO, '|', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', NO,
		'*',	// 0x30
		NO,   ' ',  NO,   NO,   NO,   NO,   NO,   NO,
		NO, NO, NO, NO, NO, NO, NO,
		'7',	// 0x40
		'8', '9', '-', '4', '5', '6', '+', '1', '2', '3', '0', '.', NO, NO, NO,
		NO,	// 0x50
		[0x97] KEY_HOME, [0x9C] '\n' /*KP_Enter*/, [0xB5] '/' /*KP_Div*/, [0xC8
																		   ] KEY_UP, [0xC9] KEY_PGUP, [0xCB] KEY_LF, [0xCD] KEY_RT, [0xCF
																																	 ] KEY_END, [0xD0] KEY_DN, [0xD1] KEY_PGDN, [0xD2] KEY_INS, [0xD3
																																																 ] KEY_DEL };

#define C(x) (x - '@')
#define KEY_SPACE 0xFF

static uint8 ctlmap[256] = {
		NO,      NO,      NO,      NO,      NO,      NO,      NO,      NO,
		NO, NO, NO, NO, NO, NO, NO, NO, C('Q'), C('W'), C('E'), C('R'), C('T'), C('Y'),
		C('U'), C('I'), C('O'), C('P'), NO, NO, '\r', NO, C('A'), C('S'), C(
				'D'), C('F'), C('G'), C('H'), C('J'), C('K'), C('L'), NO,
				NO, NO, NO, C('\\'), C('Z'), C('X'), C('C'), C('V'), C('B'), C('N'), C(
						'M'), NO, NO, C('/'), NO, NO, [0x39] KEY_SPACE, /*space*/
						[0x9D] NO, /*right Ctrl*/
						[0x97] KEY_HOME, [0xB5] C('/'), [0xC8] KEY_UP, [0xC9] KEY_PGUP, [0xCB
																						 ] KEY_LF, [0xCD] KEY_RT, [0xCF] KEY_END, [0xD0] KEY_DN, [0xD1
																																				  ] KEY_PGDN, [0xD2] KEY_INS, [0xD3] KEY_DEL };

static uint8 *charcode[4] = { normalmap, shiftmap, ctlmap, ctlmap };

/*
 * Get data from the keyboard.  If we finish a character, return it.  Else 0.
 * Return -1 if no data.
 */
static int
kbd_proc_data(void)
{
	int c;
	uint8 data;
	static uint32 shift;

	if ((inb(KBSTATP) & KBS_DIB) == 0)
		return -1;

	data = inb(KBDATAP);

	if (data == 0xE0) {
		// E0 escape character
		shift |= E0ESC;
		return 0;
	} else if (data & 0x80) {
		// Key released
		data = (shift & E0ESC ? data : data & 0x7F);
		shift &= ~(shiftcode[data] | E0ESC);
		return 0;
	} else if (shift & E0ESC) {
		// Last character was an E0 escape; or with 0x80
		data |= 0x80;
		shift &= ~E0ESC;
	}

	shift |= shiftcode[data];
	shift ^= togglecode[data];

	c = charcode[shift & (CTL | SHIFT)][data];
	if (c == KEY_DEL) {
		if (text_length > 0) {
			if (crt_pos == 1920 + text_length)
				return 0;
			else {
				text_length--;
				int crt_pos_Length = crt_pos - 1925;
				for (int i = crt_pos; crt_pos_Length <= text_length;
						++i, crt_pos_Length++) {
					crt_buf[i] = crt_buf[i + 1];
				}
				return c;
			}
		}
		return 0;
	}
	if (shift & CAPSLOCK) {
		if ('a' <= c && c <= 'z')
			c += 'A' - 'a';
		else if ('A' <= c && c <= 'Z')
			c += 'a' - 'A';
	}

	// Process special keys
	if ((int) shift == NUMLOCK && c >= '0' && c <= '9')
		return 0;
	if (c == 255)
		return 0;
	// Ctrl-Alt-Del: reboot
	if (!(~shift & (CTL | ALT)) && c == KEY_DEL) {
		cprintf("Rebooting!\n");
		outb(0x92, 0x3); // courtesy of Chris Frost
	}

	return c;
}

void
kbd_intr(void)
{
	cons_intr(kbd_proc_data);
}

void
kbd_init(void)
{
	irq_install_handler(1, &keyboard_interrupt_handler);
	if (KB_IO_METHOD == INT_SLEEP)
	{
		init_channel(&KBDchannel, "keyboard channel");
		init_kspinlock(&KBDlock, "keyboard channel lock");
	}
	else if (KB_IO_METHOD == INT_SEMAPHORE)
	{
		init_ksemaphore(&KBDsem, 0, "keyboard semaphore");
	}
}



/***** General device-independent console code *****/
// Here we manage the console input buffer,
// where we stash characters received from the keyboard or serial port
// whenever the corresponding interrupt occurs.

#define CONSBUFSIZE 512

static struct {
	uint8 buf[CONSBUFSIZE];
	uint32 rpos;
	uint32 wpos;
} cons;

// called by device interrupt routines to feed input characters
// into the circular console input buffer.
void
cons_intr(int (*proc)(void))
{
	int c;

	while ((c = (*proc)()) != -1) {
		if (c == 0)
			continue;
		cons.buf[cons.wpos++] = c;
		if (cons.wpos == CONSBUFSIZE)
			cons.wpos = 0;

		//cprintf("\nCHAR %d is written into cons.buf\n", c);
	}
}

// return the next input character from the console, or 0 if none waiting
int
cons_getc(void)
{
	int c;

	// poll for any pending input characters,
	// so that this function works even when interrupts are disabled
	// (e.g., when called from the kernel monitor).
	serial_intr();
	kbd_intr();

	// grab the next character from the input buffer.
	if (cons.rpos != cons.wpos) {
		c = cons.buf[cons.rpos++];
		if (cons.rpos == CONSBUFSIZE)
			cons.rpos = 0;
		return c;
	}
	return 0;
}

//// return the next input character from the console buffer, or 0 if none
int
cons_getc2(void)
{
	int c;
	// grab the next character from the input buffer (if any).
	if (cons.rpos != cons.wpos) {
		c = cons.buf[cons.rpos++];
		if (cons.rpos == CONSBUFSIZE)
			cons.rpos = 0;
		return c;
	}
	return 0;
}

// output a character to the console
void
cons_putc(int c)
{
	lpt_putc(c);
	cga_putc(c);
}

// initialize the console devices
void
cons_init(void)
{
	cga_init();
	kbd_init();
	serial_init();

	if (!serial_exists)
		cprintf("Serial port does not exist!\n");

	if (CONS_LCK_METHOD == LCK_SPIN)
	{
		init_kspinlock(&consspinlock, "console spin lock");
	}
	else if (CONS_LCK_METHOD == LCK_SLEEP)
	{
		init_sleeplock(&conslock, "console sleep lock");
	}
	else if (CONS_LCK_METHOD == LCK_SEMAPHORE)
	{
		init_ksemaphore(&conssem, 1, "console semaphore");
	}
}


// `High'-level console I/O.  Used by readline and cprintf from KERNEL side

void
cputchar(int c)
{
	cons_putc(c);
}

int
getchar(void)
{
	int c;

	while ((c = cons_getc()) == 0)
		/* do nothing */;
	return c;
}

int
iscons(int fdnum)
{
	// used by readline
	return 1;
}

// *************** This clear screen feature is implemented by *************
// ********* Abd-Alrahman Zedan From Team Frozen-Bytes - FCIS'24-25 ********
void
clear_screen_buffer(void)
{
	// accessing the screen buffer in the memory
	uint32 *crt_buf = (uint32*)(KERNEL_BASE + CGA_BUF);
	// setting the screen buffer content to spaces with black background
	for (int i = 0; i < CRT_SIZE; i++)
		crt_buf[i] = 0x0700 | ' ';
	crt_pos = 0; // reset_cursor_position
}

/*Keyboard Interrupt Service Routine */
void keyboard_interrupt_handler()
{
	//	char scanCode = inb(0x60) & 0x7F; //What key is pressed
	//	char press = inb(0x60) & 0x80; //Press down, or released
	//
	//	cprintf("Scan code: %d, Press: %d\n", scanCode, press);
	//cprintf("char is pressed\n");
	kbd_intr();

	//If there's a received char in the cons.buf, wakeup a waiting process (if any)
	if (cons.rpos != cons.wpos)
	{
		//cprintf("\n*******keyboard interrupt: will wakeup one process******\n");
		if (KB_IO_METHOD == INT_SLEEP)
		{
			wakeup_one(&KBDchannel);
		}
		else if (KB_IO_METHOD == INT_SEMAPHORE)
		{
			signal_ksemaphore(&KBDsem);
		}
	}
}

void cons_lock(void)
{
	if (CONS_LCK_METHOD == LCK_INT)
	{
		{
			struct Env * p = get_cpu_proc();
			if (p == NULL)
			{
				panic("cons_lock: no running process to block");
			}
			p->env_tf->tf_eflags &= ~FL_IF ;
			cprintf("\nconsole will be LOCKED by %s\n", p->prog_name);
		}
	}
	else if (CONS_LCK_METHOD == LCK_SPIN)
	{
		acquire_kspinlock(&consspinlock);
	}
	else if (CONS_LCK_METHOD == LCK_SLEEP)
	{
		acquire_sleeplock(&conslock);
	}
	else if (CONS_LCK_METHOD == LCK_SEMAPHORE)
	{
		wait_ksemaphore(&conssem);
	}
}

void cons_unlock(void)
{
	if (CONS_LCK_METHOD == LCK_INT)
	{
		{
			struct Env * p = get_cpu_proc();
			if (p == NULL)
			{
				panic("cons_unlock: no running process to block");
			}
			p->env_tf->tf_eflags |= FL_IF ;
		cprintf("\nconsole will be UN-LOCKED by %s\n", p->prog_name);
		}
	}
	else if (CONS_LCK_METHOD == LCK_SPIN)
	{
		release_kspinlock(&consspinlock);
	}
	else if (CONS_LCK_METHOD == LCK_SLEEP)
	{
		release_sleeplock(&conslock);
	}
	else if (CONS_LCK_METHOD == LCK_SEMAPHORE)
	{
		signal_ksemaphore(&conssem);
	}

}
